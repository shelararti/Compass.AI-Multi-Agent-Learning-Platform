"""
Video -> content-aware visual render pipeline (formerly a standalone
render_video.py script). Wrapped here as a package so tutor_backend's
visualize_service.py can drive it programmatically: transcribe a lecture
video, classify + extract content per chunk, and render a visuals track.
"""
